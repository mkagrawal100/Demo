﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC5.Models;
using PagedList;

namespace MVC5.Controllers
{
    public class EmployeeController : Controller
    {
		//// GET: Employee
		//public ActionResult Employee(int Page = 1, int PageSize = 6)
		//{
		//	DemoEntities1 d = new DemoEntities1();
		//	List<tblEmployee> listemployees = d.tblEmployees.ToList();
		//	PagedList<tblEmployee> model = new PagedList<tblEmployee>(listemployees, Page, PageSize);


		//	return View(model);

		//}

		public ActionResult Employee()
		{

			return View();
		}
		[HttpGet]
		public ActionResult GetEmployee()
		{
			using (DemoEntities1 d = new DemoEntities1())
			{
				var employee = d.tblEmployees.OrderBy(a => a.Id).ToList();

				return Json(new { data = employee }, JsonRequestBehavior.AllowGet);
			}
		}
	}
}