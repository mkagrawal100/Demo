﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC5.Models;
using PagedList;




namespace MVC5.Controllers
{
	public class HomeController : Controller
	{
		private DemoEntities1 _context = new DemoEntities1();
		public ActionResult Index()
		{
			return View();
		}

		public ActionResult About()
		{
			ViewBag.Message = "Your application description page.";

			return View();
		}

		public ActionResult Contact()
		{
			ViewBag.Message = "Your contact page.";

			return View();
		}



		public ActionResult Login()
		{


			return View();
		}
		//public ActionResult Employee()
		//{
		//	DemoEntities1 d = new DemoEntities1();
		//	var item = d.tblEmployees.ToList();
		//	return View(item);

		//}

		//public ActionResult Employee(int Page=1 ,int PageSize=6)
		//{
		//	DemoEntities1 d = new DemoEntities1();
		//	List<tblEmployee> listemployees = d.tblEmployees.ToList();
		//	PagedList<tblEmployee> model = new PagedList<tblEmployee>(listemployees, Page, PageSize);


		//	return View(model);

		//}
		public ActionResult Employee()
		{


			return View(_context.tblEmployees.ToList());

		}

		public ActionResult Add()
		{

			return View();
		}
		[HttpPost]
		public ActionResult Add(tblEmployee emp)
		{
			_context.tblEmployees.Add(emp);
			_context.SaveChanges();
			return RedirectToAction("Employee");

		}
	
		public ActionResult Edit(int EmpId)
		{

			List<tblEmployee> listemployees = _context.tblEmployees.ToList();

			return View(listemployees.Where(c => c.EmpId.Equals(EmpId)).SingleOrDefault());

		}
		[HttpPost]
		public ActionResult Edit(tblEmployee emp)
		{
			_context.Entry<tblEmployee>(emp).State = System.Data.EntityState.Modified;
			_context.SaveChanges();
			

			return RedirectToAction("Employee");

		}

		public ActionResult Delete(int EmpId)
		{
			List<tblEmployee> listemployees = _context.tblEmployees.ToList();
			var emp = listemployees.Where(c => c.EmpId.Equals(EmpId)).SingleOrDefault();
			_context.tblEmployees.Remove(emp);
			_context.SaveChanges();

			return RedirectToAction("Employee");

		}

	}
}