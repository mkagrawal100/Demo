import { Data } from '@angular/router';

export class Employee {
    Id :BigInteger;
    Employee_Number:string;
    Name :string;
    SBU :string;
    Job :string;
    Job_Tier :string;
    CEG :string;
    Practice :string;
    Group_Permanent_ATC :string;
    Group_Working_ATC :string;
    Contact_Number :string;
    EmailID :string;
    Group_Working_ATC1 :string;
    Status :string;
    CreatedOn :Date
    CreatedBy :string;
    ModifiedBy :string;
    ModifiedOn :Date;
    DeviceId :string
}

