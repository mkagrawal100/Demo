import { Component, OnInit,Inject } from '@angular/core';
import { EmployeeService } from '../Shared/employee.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
// import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
import { Employee } from 'src/app/Shared/employee.model';




@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styles: []
})
export class EmployeeComponent implements OnInit {
  employeeList: Employee[];
  vk : any;


  constructor(
    // public dialogRef: MatDialogRef<EmployeeComponent>,
    private employeeService: EmployeeService,
    private router: Router,
    private toastr: ToastrService)
 { }

  ngOnInit() {
    this.refreshList(); 

    this.employeeService.getEmployeeList().subscribe((res) => {
      console.log(res);
      console.log(res["data"]);
      this.employeeList = res["data"] ;
    });
   
  }

  refreshList() {
    // this.service.getEmployeeList().then(res => this.employeeList = res);

  }


  }
