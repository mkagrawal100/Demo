﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MVCWebApi.Models;
using System.Data.Entity;
using MVCWebApi.Models.Custom;
namespace MVCWebApi.Controllers
{
    public class EmployeeController : ApiController
    {
        public EmployeeController()
        {
        }

        public CommonResponse GetAllEmployees(string employee_number = "")
        {
            CommonResponse commonResponse = new CommonResponse();
            try
            {
                List<EmployeeViewModel> employeeList = null;
                using (DemoEntities dc = new DemoEntities())
                {
                    if (!string.IsNullOrEmpty(employee_number))
                    {
                        if (!dc.tblEmployees
                            .Any(e => e.Employee_Number == employee_number))
                        {
                            throw new Exception("Invalid employee number");
                        }
                    }
                    List<tblEmployee> employees = null;
                    if (string.IsNullOrEmpty(employee_number))
                    {
                        employees = dc.tblEmployees
                            .OrderBy(a => a.Id)
                            .ToList();
                    }
                    else
                    {
                        employees = dc.tblEmployees
                            .Where(e => e.Employee_Number == employee_number)
                            .OrderBy(a => a.Id)
                            .ToList();
                    }

                    if (employees != null && employees.Count > 0)
                    {
                        employeeList = new List<EmployeeViewModel>();
                        foreach (tblEmployee employee in employees)
                        {
                            EmployeeViewModel employeeViewModel = new EmployeeViewModel(employee);
                            employeeViewModel.employeeAttendanceList = dc.tblEmployeeAttendances
                                .Where(e => e.Employee_Number == employeeViewModel.employee.Employee_Number)
                                .ToList<tblEmployeeAttendance>();
                            employeeList.Add(employeeViewModel);
                        }
                    }
                }
                commonResponse.ErrorCode = CustomErrorCode.Success;
                commonResponse.ErrorMessage = "Successfully Fetched";
                commonResponse.data = employeeList;
            }
            catch (Exception ex)
            {
                commonResponse.ErrorCode = CustomErrorCode.Failure;
                commonResponse.ErrorMessage = ex.Message;
                commonResponse.exception = ex;
            }
            return commonResponse;
        }

        [HttpPost]
        public CommonResponse CreateEmployee(tblEmployee employee)
        {
            CommonResponse commonResponse = new CommonResponse();
            try
            {
                using (DemoEntities dc = new DemoEntities())
                {
                    if (employee == null)
                    {
                        throw new Exception("Invalid data");
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(employee.Employee_Number))
                        {
                            throw new Exception("Blank employee number");
                        }
                        else if (dc.tblEmployees
                                .Any(e => e.Employee_Number == employee.Employee_Number))
                        {
                            throw new Exception("Employee already registered");
                        }
                        else
                        {
                            dc.tblEmployees.Add(employee);
                            dc.Entry(employee).State = System.Data.EntityState.Added;
                            dc.SaveChanges();
                            commonResponse.ErrorCode = CustomErrorCode.Success;
                            commonResponse.ErrorMessage = "Successfully created";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                commonResponse.ErrorCode = CustomErrorCode.Failure;
                commonResponse.ErrorMessage = ex.Message;
                commonResponse.exception = ex;
            }
            return commonResponse;
        }

    }
}
