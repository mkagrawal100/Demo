﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCWebApi.Models.Custom
{
    public class EmployeeViewModel
    {
        public EmployeeViewModel(tblEmployee employee)
        {
            this.employee = employee;
        }
        public tblEmployee employee { get; set; }
        public List<tblEmployeeAttendance> employeeAttendanceList { get; set; }
    }
}