﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;

namespace MVCWebApi.Models.Custom
{
    public class CommonResponse
    {
        public CommonResponse()
        {
        }
        //public CommonResponse(HttpResponseMessage httpResponseMessage)
        //{
        //    this.httpResponseMessage = httpResponseMessage;
        //}
        //public HttpResponseMessage httpResponseMessage { get; set; }
        public object data { get; set; }
        public string ErrorMessage { get; set; }
        public CustomErrorCode ErrorCode { get; set; }
        public Exception exception { get; set; }
    }
}