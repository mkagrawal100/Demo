import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from './employee.model';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  formData: Employee;
  employees: Employee[];

  constructor(private http: HttpClient) { }

 

  getEmployeeList() {
    return this.http.get(environment.apiURL + '/Employee/GetAllEmployee');
  }

  

}
