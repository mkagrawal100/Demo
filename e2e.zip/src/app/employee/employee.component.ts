import { Component, OnInit,Inject } from '@angular/core';
import { EmployeeService } from '../Shared/employee.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
 import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { Employee } from 'src/app/Shared/employee.model';
import { AddEditEmployeeComponent } from './add-edit-employee/add-edit-employee.component';




@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styles: []
})
export class EmployeeComponent implements OnInit {
  employeeList: Employee[];
  vk : any;


  constructor(
   
    private employeeService: EmployeeService,
    private dialog: MatDialog,
    private router: Router,
    private toastr: ToastrService)
 { }

  ngOnInit() {
    this.refreshList(); 

    this.employeeService.getEmployeeList().subscribe((res) => {
      console.log(res);
      console.log(res["data"]);
      this.employeeList = res["data"] ;
    });
   
  }

  refreshList() {
    // this.service.getEmployeeList().then(res => this.employeeList = res);

  }

  AddOrEditEmployee() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = true;
    dialogConfig.disableClose = true;
    dialogConfig.width = "50%";
    dialogConfig.data = { };
    this.dialog.open(AddEditEmployeeComponent, dialogConfig).afterClosed();
  }


  }
